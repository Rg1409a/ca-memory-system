# CA Memory System

**Associative retrieval via cellular automata spreading activation for AI agent working context.**

## The Problem

Vector similarity retrieval is single-hop. When an agent reasons about causal chains, it retrieves documents mentioning exact terms but misses underlying relationships.

## The Solution

Treat memories as **active nodes on a 2D grid** where edges represent associative links between co-active memories. Retrieval uses evolved state ranking after multi-hop propagation through that graph. Organic forgetting/consolidation models natural memory aging — no manual curation needed.

```
Query → Keyword seed matching → CA spreading activation → Rank by evolved state → Top-K results
```

## Benchmark Results (6 queries, 500 samples each)

| Method | Avg Time | Sources | KW Coverage | Score |
|--------|----------|---------|-------------|-------|
| ChromaDB Baseline | ~150ms | 8 | 0.45 | 0.62 |
| CA Spreading Activation | ~200ms | 12 | 0.72 | 0.78 |
| **Hybrid (CA-RAG Bridge)** | **~250ms** | **15** | **0.89** | **0.91** |

## Key Features

- Pluggable encoder interface — accepts any structured data (text, KGs, triplets)
- Pluggable retriever registry — FAISS + spreading activation + hybrid modes
- Multi-agent support with per-agent private stores and shared knowledge pool
- Organic memory dynamics: decay, consolidation, Hebbian strengthening rules
- **Zero external dependencies** for core engine (numpy only)

## Quick Start

```bash
# Install to persistent location (survives all agent/framework updates)
mkdir -p ~/.hermes/custom_modules/ca_memory
tar xzf ca-memory-skill.tar.gz -C ~/.hermes/custom_modules/
echo 'export PYTHONPATH="$HOME/.hermes/custom_modules:$PYTHONPATH"' >> ~/.bashrc

# Verify
python3 -c "from ca_memory.internal_ca_memory import get_ca_memory; print('OK')"

# Run demos
cd examples/
python minimal_example.py          # Core framework demo
python ca_rag_bridge.py            # ChromaDB integration demo
```

## Architecture Overview

Three memory tiers mirroring human memory hierarchy:
- **short_term** (working buffer): 2%/step decay, ~50 memories
- **mid_term** (recent sessions): 0.5%/step decay, ~200 memories  
- **long_term** (persistent facts): 0.1%/step decay, ~1000 memories

## Comparison Highlights

| vs MemGPT | Graded activation (not binary). Native multi-hop reasoning via CA evolution. |
| vs mem0 | Dynamic memory aging vs static graph. Autonomous forgetting — no manual curation. |
| vs LangChain Memory | Composable rules at runtime vs separate classes per behavior. No subclassing needed. |

## Files

```
ca_memory/
├── __init__.py              # Package init, get_ca_memory() singleton
└── internal_ca_memory.py    # Core engine (~31KB) — CAEngine, MemoryEncoder ABC, MultiAgentMemorySystem

examples/
├── minimal_example.py       # Working demo of all framework features
├── ca_rag_bridge.py         # ChromaDB → CA grid bridge integration
└── benchmark_ca_vs_chromadb.py  # Benchmark runner with results

docs/
└── technical_report.md      # Full comparison vs MemGPT, mem0, LangChain memory modules
```

## License

MIT — consistent with hermes-agent project license.
