#!/usr/bin/env python3
"""
CA-RAG Bridge: Connects ChromaDB vector store to CA memory as a working context layer.

This module bridges an existing vector store with CA memory as a working context layer.

  ChromaDB (long-term factual store) → CA Engine (working context / associative recall)
  
The bridge loads ChromaDB chunks into the CA grid via the embedding encoder, then uses
CA spreading activation to retrieve semantically related memories that pure vector search
might miss due to lack of multi-hop reasoning.

Architecture:
  Query → ChromaDB top-K seeds → Encode as CA nodes → Evolve (forget/consolidate) 
        → Spread activation → Rank by evolved state → Return enriched context
  
This creates a "working memory" layer above the persistent ChromaDB store, analogous to
how human working memory integrates sensory input with long-term recall.

Usage:
    from ca_rag_bridge import CARAGBridge
    
    bridge = CARAGBridge()
    
    # Query with CA-enhanced retrieval
    results = bridge.query("How do surface properties affect device reliability?", top_k=10)
    
    # Get enriched context for LLM prompt
    context = bridge.get_enriched_context(query, llm_prompt_size=4096)
"""

import os
import sys
import json
import time
import hashlib
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Tuple, Optional, Any

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))


class CARAGBridge:
    """
    Bridges ChromaDB vector store with CA memory system.
    
    Loads ChromaDB chunks into the CA grid as working context memories,
    then uses CA spreading activation to retrieve semantically related items
    that pure vector search might miss.
    """
    
    def __init__(
        self,
        chroma_db_path: str = "/home/adc/extraction_dev/chroma_rag_db",
        collection_name: str = "knowledge_store",
        grid_size: Tuple[int, int] = (100, 100),
        ca_steps: int = 5,
        faiss_candidates: int = 30,
    ):
        self.chroma_db_path = chroma_db_path
        self.collection_name = collection_name
        self.grid_size = grid_size
        self.ca_steps = ca_steps
        self.faiss_candidates = faiss_candidates
        
        # Load ChromaDB collection
        import chromadb
        from sentence_transformers import SentenceTransformer
        
        self.client = chromadb.PersistentClient(path=chroma_db_path)
        self.collection = self.client.get_collection(collection_name)
        
        print(f"ChromaDB loaded: {self.collection.count()} chunks")
        
        # Load embedding model
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        
        # CA Engine for working context
        from nouse_hermes.memory.core.ca_engine import (
            CAEngine, MemoryDecayRule, ConsolidationRule
        )
        self.engine = CAEngine(grid_size=grid_size, neighborhood='moore')
        self.engine.register_rule('decay', MemoryDecayRule(decay_rate=0.015))
        self.engine.register_rule('consolidation', ConsolidationRule(threshold=0.6))
        
        # Cache for loaded memories (avoid re-encoding)
        self._loaded = False
        self._memories_by_tier: Dict[str, Dict[str, Any]] = {}
    
    def load_memories_from_chromadb(self):
        """Load all ChromaDB chunks into the CA grid as working context."""
        if self._loaded:
            return
        
        print("Loading ChromaDB memories into CA grid...")
        
        # Get all data from ChromaDB
        all_data = self.collection.get(
            include=['embeddings', 'documents', 'metadatas']
        )
        
        documents = all_data['documents']
        metadatas = all_data['metadatas']
        embeddings = all_data['embeddings']
        
        # Encode each chunk and place on CA grid
        for i, (doc, meta) in enumerate(zip(documents, metadatas)):
            nid = f"chroma_{i}"
            
            # Compute position from embedding hash (deterministic placement)
            emb = embeddings[i] if embeddings is not None and len(embeddings) > i else None
            pos = self._compute_grid_position(emb or [0.0] * 384, doc)
            
            # Determine tier based on content length and source
            tier = self._infer_tier(doc, meta)
            
            # Initial state from embedding norm (higher norm = more important)
            initial_state = min(1.0, max(0.1, len(doc) / 500))
            
            self.engine.set_node_state(
                nid, pos, 
                state=initial_state,
                metadata={
                    "content": doc,
                    "source": meta.get('source', 'unknown'),
                    "chunk_id": meta.get('chunk_id', f'chunk_{i}'),
                    "tier": tier,
                    "chroma_index": i,
                }
            )
        
        # Build edges between nearby nodes (spatial proximity on grid)
        self._build_adjacency_edges()
        
        self._loaded = True
        print(f"  Loaded {len(documents)} memories into CA grid")
    
    def _compute_grid_position(self, embedding: List[float], content: str) -> Tuple[int, int]:
        """Compute deterministic grid position from embedding + content hash."""
        # Use embedding first dimension for row, second for column (clamped to grid)
        r = abs(int(embedding[0] * 10)) % self.grid_size[0]
        c = abs(int(embedding[1] * 10)) % self.grid_size[1]
        
        # Add content hash offset for better distribution
        h = hashlib.md5(content.encode()).hexdigest()
        r = (r + int(h[:4], 16) % self.grid_size[0]) % self.grid_size[0]
        c = (c + int(h[4:8], 16) % self.grid_size[1]) % self.grid_size[1]
        
        return (r, c)
    
    def _infer_tier(self, content: str, metadata: Dict) -> str:
        """Infer memory tier from content characteristics."""
        length = len(content)
        source = metadata.get('source', '')
        
        # Short-term: recent/short chunks (active working context)
        if length < 200:
            return "short_term"
        # Mid-term: medium-length, domain-specific sources
        elif 'ubc' in source.lower() or 'stiction' in content.lower():
            return "mid_term"
        # Long-term: long, comprehensive documents
        else:
            return "long_term"
    
    def _build_adjacency_edges(self):
        """Build edges between spatially proximate nodes on the CA grid."""
        from nouse_hermes.memory.core.ca_engine import Edge
        
        nodes = list(self.engine.nodes.items())
        edge_count = 0
        
        for i, (nid_a, node_a) in enumerate(nodes):
            for j, (nid_b, node_b) in enumerate(nodes):
                if j <= i:
                    continue
                
                # Check spatial proximity (within 5 cells)
                dr = abs(node_a.position[0] - node_b.position[0])
                dc = abs(node_a.position[1] - node_b.position[1])
                
                if dr <= 3 and dc <= 3:
                    weight = max(0.1, 1.0 - (dr + dc) / 6.0)
                    self.engine.add_edge((nid_a, nid_b), weight=weight)
                    edge_count += 1
        
        print(f"  Built {edge_count} adjacency edges")
    
    def query(self, question: str, top_k: int = 10) -> Dict[str, Any]:
        """
        Query with CA-enhanced retrieval.
        
        Pipeline: ChromaDB vector search → seed nodes on CA grid → evolve → spread activation
        
        Returns dict with results, metadata, and enriched context.
        """
        start_time = time.time()
        
        # Ensure memories are loaded
        if not self._loaded:
            self.load_memories_from_chromadb()
        
        # Step 1: ChromaDB vector search for direct relevance (precision seeds)
        query_embedding = self.model.encode([question])[0].tolist()
        chroma_results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k * 3, self.collection.count()),
            include=['documents', 'metadatas']
        )
        
        # Step 2: Activate ChromaDB top results as CA seeds (strong signal)
        for i, (doc, meta) in enumerate(zip(
            chroma_results['documents'][0], 
            chroma_results['metadatas'][0]
        )):
            nid = f"chroma_{i}"
            node = self.engine.get_node(nid)
            
            if node is not None:
                # Scale ChromaDB similarity to CA activation range
                seed_state = min(1.0, 0.5 + len(doc) / 1000)
                self.engine.set_node_state(
                    nid, node.position, 
                    state=seed_state,
                    metadata=node.metadata
                )
        
        # Step 3: Evolve CA (forget/consolidate) for multi-hop reasoning
        evolved_states, _ = self.engine.evolve(steps=self.ca_steps)
        
        # Step 4: Spread activation from seeds for associative recall
        seed_nodes = {f"chroma_{i}": 1.0 for i in range(min(top_k * 2, len(chroma_results['documents'][0])))}
        activations = self.engine.spread_activation(seed_nodes=seed_nodes, max_steps=30)
        
        # Step 5: Rank by evolved state and return top-K
        ranked = sorted(activations.items(), key=lambda x: -x[1])[:top_k]
        
        results = []
        for nid, score in ranked:
            node = self.engine.get_node(nid)
            if node is None or score < 0.01:
                continue
            
            meta = node.metadata
            results.append({
                'node_id': nid,
                'content': meta.get('content', ''),
                'source': meta.get('source', 'unknown'),
                'chunk_id': meta.get('chunk_id', ''),
                'tier': meta.get('tier', 'unknown'),
                'score': float(score),
            })
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return {
            'query': question,
            'results': results,
            'top_k': top_k,
            'confidence': float(sum(r['score'] for r in results) / len(results)) if results else 0.0,
            'retrieval_method': 'ca_rag_bridge',
            'elapsed_ms': elapsed_ms,
        }
    
    def get_enriched_context(self, question: str, llm_prompt_size: int = 4096) -> str:
        """
        Get enriched context for LLM prompt generation.
        
        Combines ChromaDB direct matches with CA associative recall to provide
        a richer context than either method alone.
        """
        query_result = self.query(question, top_k=15)
        
        # Build context text from results
        context_parts = []
        total_len = 0
        
        for r in query_result['results']:
            content = r['content']
            
            if total_len + len(content) > llm_prompt_size:
                break
            
            source_info = f"[Source: {r['source']} | Chunk: {r['chunk_id']}]"
            context_parts.append(f"{source_info}\n{content}\n")
            total_len += len(content) + 50
        
        return "\n\n".join(context_parts)


def demo():
    """Demonstrate the CA-RAG bridge."""
    print("=" * 60)
    print("CA-RAG Bridge Demo")
    print("=" * 60)
    
    bridge = CARAGBridge()
    
    test_queries = [
        "How do surface properties affect device reliability?",
        "How does surface roughness affect adhesion force?",
        "What are the mechanisms of van der Waals forces at microscale?",
    ]
    
    for query in test_queries:
        print(f"\n{'='*60}")
        print(f"Query: {query}")
        print(f"{'='*60}")
        
        result = bridge.query(query, top_k=5)
        
        print(f"\n  Method: {result['retrieval_method']}")
        print(f"  Confidence: {result['confidence']:.3f}")
        print(f"  Time: {result['elapsed_ms']:.1f}ms")
        print(f"\n  Top {len(result['results'])} results:")
        
        for i, r in enumerate(result['results'], 1):
            preview = r['content'][:150] + "..." if len(r['content']) > 150 else r['content']
            print(f"    [{i}] (score={r['score']:.3f}) [{r['tier']}]")
            print(f"        {preview}")
    
    # Show enriched context example
    print(f"\n{'='*60}")
    print("Enriched Context Example:")
    print(f"{'='*60}")
    context = bridge.get_enriched_context(
        "How do surface properties affect device reliability?", 
        llm_prompt_size=2000
    )
    print(context[:800] + "...")


if __name__ == "__main__":
    demo()
