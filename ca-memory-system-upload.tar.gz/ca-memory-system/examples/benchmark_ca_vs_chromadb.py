#!/usr/bin/env python3
"""
Lightweight Benchmark: CA Memory Retrieval vs ChromaDB Vector Search

Uses a representative sample of 500 chunks from ChromaDB for fast iteration,
while still demonstrating the key comparison between retrieval strategies.

Usage:
    python benchmark_ca_vs_chromadb_light.py
    
Results saved to: /home/adc/nouse_hermes/examples/benchmark_results.json
"""

import os
import sys
import json
import time
import hashlib
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Any
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent.parent))


# ============================================================================
# Test Queries: Domain-agnostic queries spanning different reasoning types
# ============================================================================

TEST_QUERIES = [
    {
        "query": "How do surface properties affect device reliability?",
        "category": "direct_factual",
        "expected_keywords": ["surface", "properties", "reliability", "device"],
        "description": "Query about direct relationships between physical properties"
    },
    {
        "query": "What factors influence the durability of micro-scale components?",
        "category": "direct_factual", 
        "expected_keywords": ["durability", "micro", "components", "factors"],
        "description": "Query about relationships between multiple factors"
    },
    {
        "query": "How can manufacturing processes reduce system failures?",
        "category": "multi_hop",
        "expected_keywords": ["manufacturing", "processes", "reduce", "failures"],
        "description": "Requires connecting process steps to outcomes"
    },
    {
        "query": "What internal factors impact long-term system performance?",
        "category": "multi_hop",
        "expected_keywords": ["internal", "factors", "performance", "long-term"],
        "description": "Requires tracing causal chains from internal states to outcomes"
    },
    {
        "query": "How do material properties influence overall system behavior?",
        "category": "cross_domain",
        "expected_keywords": ["material", "properties", "system", "behavior"],
        "description": "Broad query requiring cross-domain concept association"
    },
    {
        "query": "What strategies reduce unwanted physical interactions in manufacturing?",
        "category": "cross_domain",
        "expected_keywords": ["strategies", "reduce", "interactions", "manufacturing"],
        "description": "Requires connecting physical principles to practical solutions"
    },
]


class ChromaDBBaseline:
    """Pure ChromaDB vector search baseline."""
    
    def __init__(self, sample_size: int = 500):
        import chromadb
        from sentence_transformers import SentenceTransformer
        
        self.client = chromadb.PersistentClient(
            path="/home/adc/extraction_dev/chroma_rag_db"
        )
        self.collection = self.client.get_collection("knowledge_store")
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        # Load a representative sample for local indexing
        all_data = self.collection.get(include=['embeddings', 'documents', 'metadatas'])
        docs = all_data['documents']
        embs = all_data['embeddings'] if all_data.get('embeddings') is not None else None
        metas = all_data['metadatas']
        
        # Sample evenly from the corpus
        step = max(1, len(docs) // sample_size)
        self._sample_docs = docs[::step][:sample_size]
        self._sample_embs = [embs[i] for i in range(0, len(embs), step)[:sample_size]] if embs is not None and len(embs) > 0 else None
        self._sample_metas = metas[::step][:sample_size]
        
        # Build local FAISS index on sample
        import numpy as np
        embeddings_np = np.array(self._sample_embs).astype('float32') if self._sample_embs else None
        
        if embeddings_np is not None and len(embeddings_np) > 0:
            norms = np.linalg.norm(embeddings_np, axis=1, keepdims=True)
            norms[norms == 0] = 1
            embeddings_normed = embeddings_np / norms
            
            import faiss
            quantizer = faiss.IndexFlatIP(384)
            self._index = faiss.IndexIDMap(quantizer)
            ids = np.array(list(range(len(embeddings_normed))), dtype=np.int64)
            self._index.add_with_ids(embeddings_normed, ids)
        else:
            self._index = None
        
        print(f"  ChromaDB baseline: sampled {len(self._sample_docs)} chunks")
    
    def query(self, question: str, top_k: int = 10) -> Dict[str, Any]:
        start_time = time.time()
        
        if self._index is not None:
            import numpy as np
            query_emb = self.model.encode([question])[0].reshape(1, -1).astype('float32')
            q_norm = np.linalg.norm(query_emb)
            if q_norm > 0:
                query_emb = query_emb / q_norm
            
            scores, faiss_ids = self._index.search(query_emb, min(top_k * 3, len(self._sample_docs)))
            
            results = []
            for fid, score in zip(faiss_ids[0], scores[0]):
                if score > 0 and int(fid) < len(self._sample_docs):
                    idx = int(fid)
                    results.append({
                        'content': self._sample_docs[idx][:300],
                        'source': self._sample_metas[idx].get('source', 'unknown'),
                        'chunk_id': self._sample_metas[idx].get('chunk_id', ''),
                        'score': float(score),
                    })
            results = results[:top_k]
        else:
            # Fallback to ChromaDB direct query (slower but works)
            query_embedding = self.model.encode([question])[0].tolist()
            chroma_results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=top_k,
                include=['documents', 'metadatas']
            )
            results = [
                {
                    'content': doc[:300],
                    'source': meta.get('source', 'unknown'),
                    'chunk_id': meta.get('chunk_id', ''),
                    'score': 1.0,
                }
                for doc, meta in zip(
                    chroma_results['documents'][0],
                    chroma_results['metadatas'][0]
                )
            ]
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return {
            'method': 'chromadb_baseline',
            'query': question,
            'results': results,
            'elapsed_ms': elapsed_ms,
            'num_sources': len(set(r['source'] for r in results)),
        }


class CASpreadingActivation:
    """CA engine with keyword-seeded spreading activation."""
    
    def __init__(self, sample_size: int = 500):
        from nouse_hermes.memory.core.ca_engine import (
            CAEngine, MemoryDecayRule, ConsolidationRule
        )
        
        self.engine = CAEngine(grid_size=(100, 100), neighborhood='moore')
        self.engine.register_rule('decay', MemoryDecayRule(decay_rate=0.015))
        self.engine.register_rule('consolidation', ConsolidationRule(threshold=0.6))
        
        import chromadb
        from sentence_transformers import SentenceTransformer
        
        client = chromadb.PersistentClient(path="/home/adc/extraction_dev/chroma_rag_db")
        collection = client.get_collection("knowledge_store")
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        all_data = collection.get(include=['embeddings', 'documents', 'metadatas'])
        docs = all_data['documents']
        embs = all_data['embeddings'] if all_data.get('embeddings') is not None else None
        metas = all_data['metadatas']
        
        # Sample evenly
        step = max(1, len(docs) // sample_size)
        sampled_docs = docs[::step][:sample_size]
        sampled_embs = [embs[i] for i in range(0, len(embs), step)[:sample_size]] if embs is not None and len(embs) > 0 else None
        sampled_metas = metas[::step][:sample_size]
        
        print(f"  CA engine: loaded {len(sampled_docs)} chunks")
        
        # Place on grid
        for i, (doc, meta) in enumerate(zip(sampled_docs, sampled_metas)):
            nid = f"mem_{i}"
            emb = sampled_embs[i] if sampled_embs is not None and len(sampled_embs) > i else None
            
            r = abs(int(emb[0] * 10)) % 100 if emb is not None and len(emb) > 0 else i % 100
            c = abs(int(emb[1] * 10)) % 100 if emb is not None and len(emb) > 0 else (i * 7) % 100
            
            self.engine.set_node_state(
                nid, (r, c),
                state=min(1.0, max(0.1, len(doc) / 500)),
                metadata={"content": doc, "source": meta.get('source', 'unknown')}
            )
        
        # Build adjacency edges for nearby nodes
        self._build_edges()
    
    def _build_edges(self):
        nodes = list(self.engine.nodes.items())
        count = 0
        
        for i, (nid_a, na) in enumerate(nodes):
            for j, (nid_b, nb) in enumerate(nodes):
                if j <= i:
                    continue
                
                dr = abs(na.position[0] - nb.position[0])
                dc = abs(na.position[1] - nb.position[1])
                
                if dr <= 3 and dc <= 3:
                    weight = max(0.1, 1.0 - (dr + dc) / 6.0)
                    self.engine.add_edge((nid_a, nid_b), weight=weight)
                    count += 1
        
        print(f"    Built {count} adjacency edges")
    
    def query(self, question: str, top_k: int = 10) -> Dict[str, Any]:
        start_time = time.time()
        
        # Seed nodes by keyword overlap with question
        question_lower = question.lower().split()
        seed_nodes = {}
        
        for nid, node in self.engine.nodes.items():
            content_lower = node.metadata.get('content', '').lower()
            overlap = len(set(question_lower) & set(content_lower.split()))
            
            if overlap > 0:
                score = overlap / max(len(question_lower), 1)
                seed_nodes[nid] = min(1.0, score * 2)
        
        # Evolve CA for forgetting/consolidation
        evolved_states, _ = self.engine.evolve(steps=5)
        
        # Spread activation from seeds
        activations = self.engine.spread_activation(
            seed_nodes=seed_nodes, max_steps=30
        )
        
        # Rank by evolved state
        ranked = sorted(activations.items(), key=lambda x: -x[1])[:top_k]
        
        results = []
        for nid, score in ranked:
            node = self.engine.get_node(nid)
            if node and score > 0.01:
                results.append({
                    'node_id': nid,
                    'content': node.metadata.get('content', '')[:300],
                    'source': node.metadata.get('source', 'unknown'),
                    'score': float(score),
                })
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return {
            'method': 'ca_spreading_activation',
            'query': question,
            'results': results,
            'elapsed_ms': elapsed_ms,
            'num_sources': len(set(r['source'] for r in results)),
            'seed_count': len(seed_nodes),
        }


class HybridCA_RAG:
    """Hybrid CA-RAG bridge (ChromaDB seeds -> CA evolution -> ranked recall)."""
    
    def __init__(self, sample_size: int = 500):
        from nouse_hermes.memory.core.ca_engine import (
            CAEngine, MemoryDecayRule, ConsolidationRule
        )
        
        self.engine = CAEngine(grid_size=(100, 100), neighborhood='moore')
        self.engine.register_rule('decay', MemoryDecayRule(decay_rate=0.015))
        self.engine.register_rule('consolidation', ConsolidationRule(threshold=0.6))
        
        import chromadb
        from sentence_transformers import SentenceTransformer
        
        client = chromadb.PersistentClient(path="/home/adc/extraction_dev/chroma_rag_db")
        self.collection = client.get_collection("knowledge_store")
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        
        all_data = self.collection.get(include=['embeddings', 'documents', 'metadatas'])
        docs = all_data['documents']
        embs = all_data['embeddings'] if all_data.get('embeddings') is not None else None
        metas = all_data['metadatas']
        
        step = max(1, len(docs) // sample_size)
        sampled_docs = docs[::step][:sample_size]
        sampled_embs = [embs[i] for i in range(0, len(embs), step)[:sample_size]] if embs is not None and len(embs) > 0 else None
        sampled_metas = metas[::step][:sample_size]
        
        print(f"  Hybrid CA-RAG: loaded {len(sampled_docs)} chunks")
        
        for i, (doc, meta) in enumerate(zip(sampled_docs, sampled_metas)):
            nid = f"mem_{i}"
            emb = sampled_embs[i] if sampled_embs is not None and len(sampled_embs) > i else None
            
            r = abs(int(emb[0] * 10)) % 100 if emb is not None and len(emb) > 0 else i % 100
            c = abs(int(emb[1] * 10)) % 100 if emb is not None and len(emb) > 0 else (i * 7) % 100
            
            self.engine.set_node_state(
                nid, (r, c),
                state=min(1.0, max(0.1, len(doc) / 500)),
                metadata={"content": doc, "source": meta.get('source', 'unknown')}
            )
        
        self._build_edges()
    
    def _build_edges(self):
        nodes = list(self.engine.nodes.items())
        count = 0
        
        for i, (nid_a, na) in enumerate(nodes):
            for j, (nid_b, nb) in enumerate(nodes):
                if j <= i:
                    continue
                
                dr = abs(na.position[0] - nb.position[0])
                dc = abs(na.position[1] - nb.position[1])
                
                if dr <= 3 and dc <= 3:
                    weight = max(0.1, 1.0 - (dr + dc) / 6.0)
                    self.engine.add_edge((nid_a, nid_b), weight=weight)
                    count += 1
        
        print(f"    Built {count} adjacency edges")
    
    def query(self, question: str, top_k: int = 10) -> Dict[str, Any]:
        start_time = time.time()
        
        # Step 1: ChromaDB vector search for precision seeds (on sample)
        query_emb = self.model.encode([question])[0].reshape(1, -1).astype('float32')
        q_norm = np.linalg.norm(query_emb)
        if q_norm > 0:
            query_emb = query_emb / q_norm
        
        # Build FAISS index on sample for seed matching
        all_data = self.collection.get(include=['embeddings', 'documents', 'metadatas'])
        sampled_docs_list = all_data['documents'][::max(1, len(all_data['documents'])//500)][:500]
        sampled_embs_list = [all_data['embeddings'][i] for i in range(0, len(all_data['embeddings']), max(1, len(all_data['embeddings'])//500))][:500] if all_data.get('embeddings') is not None and len(all_data['embeddings']) > 0 else []
        sampled_metas_list = all_data['metadatas'][::max(1, len(all_data['metadatas'])//500)][:500]
        
        embeddings_np = np.array(sampled_embs_list).astype('float32') if sampled_embs_list else None
        
        if embeddings_np is not None and len(embeddings_np) > 0:
            norms = np.linalg.norm(embeddings_np, axis=1, keepdims=True)
            norms[norms == 0] = 1
            embeddings_normed = embeddings_np / norms
            
            import faiss
            quantizer = faiss.IndexFlatIP(384)
            index = faiss.IndexIDMap(quantizer)
            ids = np.array(list(range(len(embeddings_normed))), dtype=np.int64)
            index.add_with_ids(embeddings_normed, ids)
            
            scores, faiss_ids = index.search(query_emb, min(top_k * 3, len(sampled_embs_list)))
            
            # Step 2: Activate ChromaDB top results as CA seeds
            for fid, score in zip(faiss_ids[0], scores[0]):
                if score > 0 and int(fid) < len(sampled_docs_list):
                    nid = f"mem_{int(fid)}"
                    node = self.engine.get_node(nid)
                    if node is not None:
                        seed_state = min(1.0, 0.5 + score * 0.5)
                        self.engine.set_node_state(
                            nid, node.position, 
                            state=seed_state,
                            metadata=node.metadata
                        )
        
        # Step 3: Evolve CA (forget/consolidate)
        evolved_states, _ = self.engine.evolve(steps=5)
        
        # Step 4: Spread activation from seeds
        seed_nodes = {f"mem_{i}": 1.0 for i in range(min(top_k * 2, len(self.engine.nodes)))}
        activations = self.engine.spread_activation(seed_nodes=seed_nodes, max_steps=30)
        
        # Step 5: Rank by evolved state -> top-K
        ranked = sorted(activations.items(), key=lambda x: -x[1])[:top_k]
        
        results = []
        for nid, score in ranked:
            node = self.engine.get_node(nid)
            if node and score > 0.01:
                results.append({
                    'node_id': nid,
                    'content': node.metadata.get('content', '')[:300],
                    'source': node.metadata.get('source', 'unknown'),
                    'score': float(score),
                })
        
        elapsed_ms = (time.time() - start_time) * 1000
        
        return {
            'method': 'hybrid_ca_rag',
            'query': question,
            'results': results,
            'elapsed_ms': elapsed_ms,
            'num_sources': len(set(r['source'] for r in results)),
        }


def evaluate_query_results(
    query_info: Dict, 
    method_results: List[Dict]
) -> Dict[str, Any]:
    """Evaluate retrieval quality for a single query across methods."""
    
    expected_kws = set(query_info.get('expected_keywords', []))
    
    evals = {}
    for mr in method_results:
        num_sources = mr.get('num_sources', 0)
        
        all_content = " ".join(r['content'] for r in mr['results'])
        found_kws = len(expected_kws & set(all_content.lower().split()))
        keyword_coverage = found_kws / max(len(expected_kws), 1)
        
        scores = [r['score'] for r in mr['results']]
        mean_score = sum(scores) / len(scores) if scores else 0
        
        evals[mr['method']] = {
            'num_results': len(mr['results']),
            'num_sources': num_sources,
            'keyword_coverage': keyword_coverage,
            'mean_score': mean_score,
            'elapsed_ms': mr['elapsed_ms'],
        }
    
    return evals


def run_benchmark():
    """Run the full benchmark across all queries and methods."""
    print("=" * 70)
    print("  CA Memory Retrieval vs ChromaDB Vector Search Benchmark")
    print("  Domain-Agnostic Queries (500-chunk sample)")
    print("=" * 70)
    
    # Initialize retrievers
    print("\nInitializing retrievers...")
    chromadb_baseline = ChromaDBBaseline(sample_size=500)
    ca_spreading = CASpreadingActivation(sample_size=500)
    hybrid_ca_rag = HybridCA_RAG(sample_size=500)
    print("  All retrievers initialized.\n")
    
    # Run queries
    all_results = []
    
    for qi, qinfo in enumerate(TEST_QUERIES, 1):
        query = qinfo['query']
        category = qinfo['category']
        
        print(f"[{qi}/{len(TEST_QUERIES)}] Query ({category}): {query}")
        print("-" * 60)
        
        method_results = []
        
        # ChromaDB baseline
        t0 = time.time()
        cr1 = chromadb_baseline.query(query, top_k=10)
        elapsed1 = (time.time() - t0) * 1000
        cr1['elapsed_ms'] = elapsed1
        method_results.append(cr1)
        
        # CA spreading activation
        t0 = time.time()
        cr2 = ca_spreading.query(query, top_k=10)
        elapsed2 = (time.time() - t0) * 1000
        cr2['elapsed_ms'] = elapsed2
        method_results.append(cr2)
        
        # Hybrid CA-RAG
        t0 = time.time()
        cr3 = hybrid_ca_rag.query(query, top_k=10)
        elapsed3 = (time.time() - t0) * 1000
        cr3['elapsed_ms'] = elapsed3
        method_results.append(cr3)
        
        # Evaluate
        evals = evaluate_query_results(qinfo, method_results)
        
        for method_name, ev in evals.items():
            print(f"  {method_name:25s} | results={ev['num_results']:2d} | "
                  f"sources={ev['num_sources']:2d} | kw_cov={ev['keyword_coverage']:.2f} | "
                  f"score={ev['mean_score']:.3f} | time={ev['elapsed_ms']:.0f}ms")
        
        all_results.append({
            'query': query,
            'category': category,
            'expected_keywords': qinfo.get('expected_keywords', []),
            'description': qinfo.get('description', ''),
            'method_results': method_results,
            'evaluation': evals,
        })
        
        print()
    
    # Aggregate results
    print("=" * 70)
    print("AGGREGATED RESULTS")
    print("=" * 70)
    
    agg = defaultdict(lambda: {'total_time': 0, 'count': 0, 'evals': []})
    
    for qr in all_results:
        for method_name, ev in qr['evaluation'].items():
            agg[method_name]['total_time'] += ev['elapsed_ms']
            agg[method_name]['count'] += 1
            agg[method_name]['evals'].append(ev)
    
    print(f"\n{'Method':25s} | {'Avg Time (ms)':>14s} | {'Avg Sources':>11s} | "
          f"{'Avg KW Coverage':>15s} | {'Avg Score':>9s}")
    print("-" * 70)
    
    for method_name in sorted(agg.keys()):
        data = agg[method_name]
        n = data['count']
        
        avg_time = data['total_time'] / n
        avg_sources = sum(e['num_sources'] for e in data['evals']) / n
        avg_kw = sum(e['keyword_coverage'] for e in data['evals']) / n
        avg_score = sum(e['mean_score'] for e in data['evals']) / n
        
        print(f"{method_name:25s} | {avg_time:>14.0f} | {avg_sources:>11.1f} | "
              f"{avg_kw:>15.3f} | {avg_score:>9.3f}")
    
    # Save results
    output_path = "/home/adc/nouse_hermes/examples/benchmark_results.json"
    with open(output_path, 'w') as f:
        json.dump({
            'benchmark_date': time.strftime('%Y-%m-%d %H:%M:%S'),
            'num_queries': len(TEST_QUERIES),
            'sample_size': 500,
            'queries_by_category': dict(Counter(q['category'] for q in TEST_QUERIES)),
            'results': all_results,
        }, f, indent=2)
    
    print(f"\nResults saved to: {output_path}")


if __name__ == "__main__":
    run_benchmark()
