"""
Internal CA Memory — Self-Referential Memory Management for Hermes Agent
========================================================================

Adapts the Nouse Hermes LACE cellular automata framework for *internal* use.
Instead of deploying as an external service, this wraps the CA engine to provide:

  1. Associative retrieval via spreading activation (not keyword search)
  2. Organic forgetting — memories decay based on usage patterns
  3. Tiered memory with promotion/demotion logic
  4. Integration with existing Hermes Agent tools (memory, session_search)

Architecture:
    Working Context (short-term)  ← CA grid state, transient
    Recent Sessions (mid-term)    ← session_search results, moderate stability  
    Persistent Memory (long-term) ← memory tool entries, highly stable

The CA engine drives dynamics *within* each tier and across tiers.
Retrieval uses spreading activation from semantic seeds to find related memories.

Usage:
    from memory.internal_ca_memory import InternalCAMemory
    
    # Initialize (auto-loads existing persistent memory)
    ca_mem = InternalCAMemory()
    
    # Encode a new memory
    ca_mem.encode("User prefers HTML output for complex data", tier="long_term")
    
    # Retrieve related memories via spreading activation
    results = ca_mem.retrieve("user preferences, output format")
    
    # Evolve (run forgetting/consolidation cycle)
    ca_mem.evolve(steps=10)

Key differences from external LACE deployment:
  - No FAISS/sentence-transformers dependency; uses keyword-based seeding
  - Tier storage maps to existing Hermes tools, not in-memory dicts
  - Persistence via memory tool + JSON file backup
  - Lightweight CA grid (50x50 vs 100x100) for internal use
"""

from __future__ import annotations

import os
import sys
import json
import math
import logging
import hashlib
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Set, Tuple, Optional, Any
from datetime import datetime, timedelta
from collections import defaultdict
from pathlib import Path

# Import core CA engine from existing codebase
sys_path_fix = "/home/adc/nouse_hermes"
if sys_path_fix not in sys.path:
    sys.path.insert(0, sys_path_fix)

try:
    from memory.core.ca_engine import CARule, NodeState, Edge as CAEdge
    from memory.rules import DecayRule, HebbianRule, SpreadingActivationRule
except ImportError:
    # Fallback: minimal inline implementations if imports fail
    CARule = None
    NodeState = None
    CAEdge = None

logger = logging.getLogger(__name__)


# ============================================================================
# Data Models (lightweight, no numpy dependency)
# ============================================================================

@dataclass
class MemoryTrace:
    """A single memory trace in the internal CA system."""
    id: str
    content: str
    state: float                    # Activation strength 0.0-1.0
    tier: str                       # short_term, mid_term, long_term
    semantic_type: str = "observation"
    causal_role: str = "leaf"       # root, hub, leaf, bridge
    age: int = 0                    # CA steps survived
    last_active: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    source_tool: str = ""           # Which Hermes tool created this (memory, session_search, etc.)
    
    def __post_init__(self):
        if not self.last_active:
            self.last_active = datetime.now().isoformat()
    
    @property
    def strength(self) -> float:
        """Effective memory strength (state * age factor)."""
        age_factor = min(1.0, self.age / 50.0)
        return self.state * (0.3 + 0.7 * age_factor)
    
    @property
    def is_active(self) -> bool:
        return self.state > 0.01
    
    def to_dict(self) -> dict:
        d = asdict(self)
        return d
    
    @classmethod
    def from_dict(cls, d: dict) -> 'MemoryTrace':
        d = d.copy()
        if "tags" not in d or d["tags"] is None:
            d["tags"] = []
        return cls(**d)


@dataclass 
class RetrievalResult:
    """Result of a spreading activation retrieval."""
    query: str
    results: List[Tuple[str, float]]  # (memory_id, activation_score)
    top_k: int = 5
    confidence: float = 0.0
    
    def to_context_string(self, max_chars: int = 2000) -> str:
        """Format results as enriched context for LLM prompts."""
        lines = [f"=== Retrieved Context (query: '{self.query}') ===\n"]
        total_len = len(lines[0])
        
        for i, (nid, score) in enumerate(self.results[:self.top_k], 1):
            content = self._get_content(nid)
            if not content:
                continue
            
            truncated = content[:500] + ("..." if len(content) > 500 else "")
            line = f"[{i}] (score={score:.3f}) {nid}:\n    {truncated}\n"
            
            if total_len + len(line) > max_chars:
                lines.append(f"... [{len(self.results)} more results truncated]")
                break
            
            lines.append(line)
            total_len += len(line)
        
        return "\n".join(lines)
    
    def _get_content(self, nid: str) -> str:
        """Get content for a retrieved memory ID."""
        if hasattr(self, '_memory_store'):
            mem = self._memory_store.get(nid)
            if mem:
                return mem.content if isinstance(mem, MemoryTrace) else str(mem)
        return ""


# ============================================================================
# Keyword-based seeding (replacement for FAISS when embeddings unavailable)
# ============================================================================

def _keyword_similarity(query: str, text: str) -> float:
    """Compute keyword overlap similarity between query and text."""
    if not query or not text:
        return 0.0
    
    # Normalize: lowercase, remove punctuation, split to words
    def tokenize(s):
        s = s.lower()
        words = []
        current = []
        for c in s:
            if c.isalnum():
                current.append(c)
            else:
                if current:
                    words.append(''.join(current))
                    current = []
        if current:
            words.append(''.join(current))
        return set(words)
    
    query_words = tokenize(query)
    text_words = tokenize(text)
    
    if not query_words or not text_words:
        return 0.0
    
    # Jaccard-like overlap with term frequency weighting
    intersection = query_words & text_words
    union = query_words | text_words
    
    base_score = len(intersection) / len(union) if union else 0.0
    
    # Boost for exact phrase matches (simple n-gram check)
    query_terms = tokenize(query)
    for term in query_terms:
        if len(term) > 3 and term in text.lower():
            base_score += 0.1
    
    return min(1.0, base_score)


def _find_semantic_seeds(query: str, memories_by_tier: Dict[str, Dict[str, MemoryTrace]], top_k: int = 20) -> List[Tuple[str, float]]:
    """Find seed memories most semantically related to the query using keyword overlap."""
    scores = []
    
    for tier_name, tier_memories in memories_by_tier.items():
        for nid, mem in tier_memories.items():
            if not mem.is_active or not mem.content.strip():
                continue
            
            score = _keyword_similarity(query, mem.content)
            # Boost based on tier (long-term memories get slight boost for stability)
            tier_boost = {"short_term": 1.0, "mid_term": 1.1, "long_term": 1.2}.get(tier_name, 1.0)
            scores.append((nid, score * tier_boost))
    
    # Sort by score descending and return top_k
    scores.sort(key=lambda x: x[1], reverse=True)
    return [(nid, max(0.0, s)) for nid, s in scores[:top_k] if s > 0.01]


# ============================================================================
# Internal CA Memory Engine
# ============================================================================

class InternalCAMemory:
    """
    Self-referential cellular automata memory system for Hermes Agent.
    
    Wraps the LACE CA engine to provide associative memory dynamics
    over the agent's own persistent and session-based memories.
    
    This is NOT a replacement for existing memory tools — it's an
    associative retrieval layer that sits on top of them.
    """
    
    def __init__(
        self,
        grid_size: int = 50,
        decay_rate: float = 0.015,
        consolidation_threshold: float = 0.6,
        storage_dir: Optional[str] = None,
    ):
        # CA engine configuration
        self.grid_size = grid_size
        self.decay_rate = decay_rate
        self.consolidation_threshold = consolidation_threshold
        
        # Storage directory for persistence
        self.storage_dir = storage_dir or os.path.expanduser("~/.hermes/ca_memory")
        os.makedirs(self.storage_dir, exist_ok=True)
        
        # Memory stores — the actual data structures
        self.short_term: Dict[str, MemoryTrace] = {}      # Working buffer (transient)
        self.mid_term: Dict[str, MemoryTrace] = {}         # Recent sessions (moderate stability)
        self.long_term: Dict[str, MemoryTrace] = {}        # Persistent memories (highly stable)
        
        # Associative graph (edges between co-active memories)
        self.edges: Dict[Tuple[str, str], float] = defaultdict(float)  # (nid1, nid2) -> weight
        
        # CA evolution state
        self.ca_step: int = 0
        self.node_history: Dict[str, List[float]] = defaultdict(list)  # State history per node
        
        # Metrics
        self.metrics = {
            "total_memories_encoded": 0,
            "total_retrievals": 0,
            "tier_promotions": {"short_to_mid": 0, "mid_to_long": 0},
            "last_evolve_step": 0,
        }
        
        # Load existing persistent state
        self._load_state()
        
        logger.info(f"InternalCAMemory initialized: grid={grid_size}x{grid_size}, "
                    f"decay={decay_rate}, loaded {len(self.short_term)} short + "
                    f"{len(self.mid_term)} mid + {len(self.long_term)} long term memories")

    # ------------------------------------------------------------------
    # Memory Encoding (writing to tiers)
    # ------------------------------------------------------------------

    def encode(
        self,
        content: str,
        tier: str = "short_term",
        semantic_type: str = "observation",
        tags: Optional[List[str]] = None,
        source_tool: str = "",
        parent_ids: Optional[List[str]] = None,
        initial_strength: float = 0.8,
    ) -> MemoryTrace:
        """
        Encode a memory into the specified tier.
        
        Maps content to a node in the CA grid with edges to related memories.
        For internal use, this wraps existing Hermes Agent memory operations.
        """
        if not content.strip():
            return None
        
        # Generate unique ID
        content_hash = hashlib.md5(content.encode()).hexdigest()[:12]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        node_id = f"mem_{tier[:3]}_{timestamp}_{content_hash}"
        
        # Determine causal role from content analysis
        causal_role = self._infer_causal_role(content, semantic_type)
        
        trace = MemoryTrace(
            id=node_id,
            content=content.strip(),
            state=initial_strength,
            tier=tier,
            semantic_type=semantic_type,
            causal_role=causal_role,
            tags=tags or [],
            source_tool=source_tool,
        )
        
        # Add to appropriate tier store
        if tier == "short_term":
            self.short_term[node_id] = trace
        elif tier == "mid_term":
            self.mid_term[node_id] = trace
        elif tier == "long_term":
            self.long_term[node_id] = trace
        
        # Create edges to parent memories (associative links)
        if parent_ids:
            for parent_id in parent_ids:
                edge_key = tuple(sorted([node_id, parent_id]))
                current_weight = self.edges[edge_key]
                self.edges[edge_key] = min(1.0, current_weight + 0.3)  # Strengthen link
        
        # Track state history
        self.node_history[node_id].append(initial_strength)
        
        self.metrics["total_memories_encoded"] += 1
        
        logger.debug(f"Encoded memory '{node_id}': tier={tier}, type={semantic_type}, strength={initial_strength:.2f}")
        
        return trace

    def encode_from_session_search(self, query: str, results: List[Dict], tier: str = "mid_term") -> List[MemoryTrace]:
        """Encode session search results as mid-term memories."""
        traces = []
        for i, result in enumerate(results[:10]):  # Limit to top 10
            content = result.get("summary", result.get("content", ""))
            if not content:
                continue
            
            trace = self.encode(
                content=content,
                tier=tier,
                semantic_type="session_result",
                tags=[query],
                source_tool="session_search",
                initial_strength=0.6,
            )
            traces.append(trace)
        
        return traces

    # ------------------------------------------------------------------
    # Retrieval via Spreading Activation
    # ------------------------------------------------------------------

    def retrieve(
        self,
        query: str,
        top_k: int = 10,
        ca_steps: int = 5,
        include_tiers: Optional[List[str]] = None,
    ) -> RetrievalResult:
        """
        Retrieve memories relevant to a query using spreading activation.
        
        Pipeline (internal version):
            1. Keyword-based seed matching → find initial related memories
            2. CA spreading activation → propagate through associative graph
            3. Rank by evolved state → return top-K highest-state nodes
        
        This combines keyword precision with CA's multi-hop reasoning capability.
        """
        if include_tiers is None:
            include_tiers = ["short_term", "mid_term", "long_term"]
        
        # Collect memories from requested tiers
        all_memories = {}
        for tier_name in include_tiers:
            store = getattr(self, tier_name, {})
            all_memories.update(store)
        
        if not all_memories:
            return RetrievalResult(query=query, results=[], top_k=top_k)
        
        # Step 1: Find semantic seeds (keyword-based for internal use)
        memories_by_tier = {t: getattr(self, t, {}) for t in include_tiers}
        seeds = _find_semantic_seeds(query, memories_by_tier, top_k=30)
        
        if not seeds:
            return RetrievalResult(query=query, results=[], top_k=top_k)
        
        # Step 2: Run spreading activation from seeds
        activations = self._spread_activation(seeds, steps=ca_steps)
        
        # Step 3: Rank by evolved state and return top-K
        ranked = sorted(activations.items(), key=lambda x: x[1], reverse=True)
        top_results = [(nid, score) for nid, score in ranked[:top_k] if score > 0.01]
        
        # Calculate confidence based on activation spread
        max_activation = max((s for _, s in top_results), default=0.0)
        confidence = min(1.0, max_activation * 2.0)  # Scale to 0-1
        
        result = RetrievalResult(
            query=query,
            results=top_results,
            top_k=top_k,
            confidence=confidence,
        )
        
        # Attach memory store for context string generation
        result._memory_store = all_memories
        
        self.metrics["total_retrievals"] += 1
        
        logger.debug(f"Retrieved {len(top_results)} memories for query '{query[:50]}...' "
                     f"(confidence={confidence:.3f})")
        
        return result

    def _spread_activation(
        self,
        seeds: List[Tuple[str, float]],
        steps: int = 5,
    ) -> Dict[str, float]:
        """Run spreading activation from seed nodes through the associative graph."""
        # Initialize activations for all active nodes
        all_nodes = set()
        all_nodes.update(self.short_term.keys())
        all_nodes.update(self.mid_term.keys())
        all_nodes.update(self.long_term.keys())
        
        activations = {nid: 0.0 for nid in all_nodes}
        
        # Initialize seeds with their scores (strong signal)
        for nid, score in seeds:
            if nid in activations:
                activations[nid] = max(activations[nid], min(1.0, score * 2.0))
        
        # Propagate through the graph
        for step in range(steps):
            new_activations = dict(activations)
            
            for nid, current_state in activations.items():
                if current_state < 1e-6:
                    continue
                
                # Spread to neighbors via edges
                for (src, tgt), weight in self.edges.items():
                    neighbor_id = None
                    if src == nid:
                        neighbor_id = tgt
                    elif tgt == nid:
                        neighbor_id = src
                    
                    if neighbor_id is None or neighbor_id not in new_activations:
                        continue
                    
                    # Spread amount: current_state * edge_weight * decay_factor
                    spread = current_state * weight * 0.3 * 0.9
                    new_activations[neighbor_id] = min(1.0, new_activations[neighbor_id] + spread)
            
            activations = new_activations
            
            # Check convergence
            max_change = max(abs(activations[nid] - new_activations.get(nid, 0))
                           for nid in activations if nid in new_activations)
            if max_change < 1e-4:
                break
        
        return activations

    # ------------------------------------------------------------------
    # CA Evolution (forgetting and consolidation)
    # ------------------------------------------------------------------

    def evolve(self, steps: int = 10) -> Dict[str, Any]:
        """
        Run CA evolution for N steps.
        
        Each step applies memory dynamics:
          - Decay: memories lose activation over time
          - Consolidation: frequently accessed memories strengthen
          - Promotion: persistent memories move to higher tiers
        
        Returns evolution summary with metrics.
        """
        all_states = {}
        
        for step in range(steps):
            self.ca_step += 1
            
            # Apply decay to each tier at different rates
            short_decay = 0.02      # Fast decay for working buffer
            mid_decay = 0.005       # Moderate decay for recent sessions
            long_decay = 0.001      # Very slow decay for persistent memory
            
            tiers_with_rates = [
                (self.short_term, short_decay),
                (self.mid_term, mid_decay),
                (self.long_term, long_decay),
            ]
            
            for tier_store, rate in tiers_with_rates:
                for nid, trace in list(tier_store.items()):
                    if not trace.is_active:
                        continue
                    
                    # Decay based on age (older memories decay slower)
                    age_factor = max(0.1, 1.0 - trace.age / 200.0)
                    effective_decay = rate * age_factor
                    
                    new_state = trace.state * (1.0 - effective_decay)
                    
                    # Apply Hebbian strengthening for recently accessed memories
                    history = self.node_history.get(nid, [])
                    if len(history) >= 3:
                        recent_avg = sum(history[-3:]) / min(3, len(history))
                        if recent_avg > trace.state * 1.2:
                            # Strengthening effect (memories used recently get a boost)
                            new_state = max(new_state, trace.state * 0.95)
                    
                    trace.state = new_state
                    self.node_history[nid].append(new_state)
            
            # Clean up dead nodes (state ≈ 0)
            for tier_name in ["short_term", "mid_term"]:
                store = getattr(self, tier_name)
                dead_nodes = [nid for nid, trace in store.items() if not trace.is_active]
                for nid in dead_nodes:
                    del store[nid]
                    self.node_history.pop(nid, None)
            
            # Check for promotions (short → mid → long)
            promotions = self._check_promotions()
            for nid, new_tier in promotions:
                source_store = None
                for tier_name in ["short_term", "mid_term"]:
                    if nid in getattr(self, tier_name):
                        source_store = tier_name
                        break
                
                if source_store and new_tier != source_store:
                    trace = self[source_store].pop(nid)
                    trace.tier = new_tier
                    setattr(self, new_tier, {**getattr(self, new_tier), nid: trace})
                    self.metrics["tier_promotions"][f"{source_store}_to_{new_tier}"] += 1
            
            # Collect states for summary
            for tier_name in ["short_term", "mid_term", "long_term"]:
                store = getattr(self, tier_name)
                all_states.update({nid: trace.state for nid, trace in store.items()})
        
        self.metrics["last_evolve_step"] = self.ca_step
        
        # Save state after evolution
        self._save_state()
        
        return {
            "steps_run": steps,
            "final_ca_step": self.ca_step,
            "tier_counts": {
                "short_term": len(self.short_term),
                "mid_term": len(self.mid_term),
                "long_term": len(self.long_term),
            },
            "avg_states": {
                tier: (sum(t.state for t in store.values()) / max(1, len(store)))
                for tier, store in [("short", self.short_term), ("mid", self.mid_term), ("long", self.long_term)]
            } if any([self.short_term, self.mid_term, self.long_term]) else {}
        }

    def _check_promotions(self) -> List[Tuple[str, str]]:
        """Check for memories eligible for tier promotion."""
        promotions = []
        
        # Short → Mid: survived enough steps above threshold
        for nid, trace in list(self.short_term.items()):
            if (trace.age >= 10 and 
                trace.state > self.consolidation_threshold * 0.7):
                history = self.node_history.get(nid, [])
                if len(history) >= 5:
                    recent_avg = sum(history[-5:]) / min(5, len(history))
                    if recent_avg > self.consolidation_threshold * 0.6:
                        promotions.append((nid, "mid_term"))
        
        # Mid → Long: high persistence and centrality (simplified)
        for nid, trace in list(self.mid_term.items()):
            if (trace.age >= 30 and 
                trace.state > self.consolidation_threshold * 0.5):
                promotions.append((nid, "long_term"))
        
        return promotions

    # ------------------------------------------------------------------
    # Tier Management Helpers
    # ------------------------------------------------------------------

    def get_tier_stats(self) -> Dict[str, Any]:
        """Get statistics about tier distribution and health."""
        stats = {}
        for tier_name in ["short_term", "mid_term", "long_term"]:
            store = getattr(self, tier_name, {})
            if store:
                states = [t.state for t in store.values()]
                stats[tier_name] = {
                    "count": len(store),
                    "avg_state": sum(states) / len(states),
                    "max_state": max(states),
                    "min_state": min(states),
                }
            else:
                stats[tier_name] = {"count": 0}
        
        return {**stats, "metrics": self.metrics.copy()}

    def _infer_causal_role(self, content: str, semantic_type: str) -> str:
        """Infer causal role from content and type."""
        content_lower = content.lower()
        
        # Check for rule/fact patterns
        if any(kw in content_lower for kw in ["must", "should", "always", "never", "rule", "principle"]):
            return "root"
        
        # Check for hub/concept patterns
        if semantic_type == "concept":
            return "hub"
        
        # Check for bridge patterns (connecting ideas)
        if any(kw in content_lower for kw in ["therefore", "because", "leads to", "causes", "enables"]):
            return "bridge"
        
        return "leaf"

    # ------------------------------------------------------------------
    # Persistence (save/load state)
    # ------------------------------------------------------------------

    def _get_state_file(self) -> str:
        """Get path to the persistent state file."""
        return os.path.join(self.storage_dir, "ca_memory_state.json")

    def _save_state(self):
        """Serialize and save CA memory state to disk."""
        state = {
            "version": 1,
            "timestamp": datetime.now().isoformat(),
            "ca_step": self.ca_step,
            "metrics": self.metrics,
            "short_term": {nid: t.to_dict() for nid, t in self.short_term.items()},
            "mid_term": {nid: t.to_dict() for nid, t in self.mid_term.items()},
            "long_term": {nid: t.to_dict() for nid, t in self.long_term.items()},
            "edges": {f"{k[0]}|{k[1]}": v for k, v in self.edges.items()},
        }
        
        state_file = self._get_state_file()
        try:
            with open(state_file, 'w') as f:
                json.dump(state, f, indent=2)
            logger.debug(f"Saved CA memory state to {state_file}")
        except Exception as e:
            logger.error(f"Failed to save CA memory state: {e}")

    def _load_state(self):
        """Load CA memory state from disk if available."""
        state_file = self._get_state_file()
        
        if not os.path.exists(state_file):
            logger.debug("No existing CA memory state found — starting fresh")
            return
        
        try:
            with open(state_file, 'r') as f:
                state = json.load(f)
            
            # Restore tiers
            for tier_name in ["short_term", "mid_term", "long_term"]:
                store_key = tier_name
                tier_data = state.get(store_key, {})
                target_store = getattr(self, store_key)
                
                for nid, trace_dict in tier_data.items():
                    try:
                        trace = MemoryTrace.from_dict(trace_dict)
                        target_store[nid] = trace
                    except Exception as e:
                        logger.warning(f"Failed to restore memory {nid}: {e}")
            
            # Restore edges
            for key_str, weight in state.get("edges", {}).items():
                parts = key_str.split("|")
                if len(parts) == 2:
                    self.edges[(parts[0], parts[1])] = weight
            
            # Restore CA step counter
            self.ca_step = state.get("ca_step", 0)
            
            # Restore metrics (but don't overwrite current counts)
            saved_metrics = state.get("metrics", {})
            for key in ["total_retrievals", "last_evolve_step"]:
                if key in saved_metrics:
                    self.metrics[key] = saved_metrics[key]
            
            logger.info(f"Loaded CA memory state: {len(self.short_term)} short + "
                       f"{len(self.mid_term)} mid + {len(self.long_term)} long term memories")
        
        except Exception as e:
            logger.error(f"Failed to load CA memory state: {e}")

    # ------------------------------------------------------------------
    # Convenience Methods for Integration with Existing Tools
    # ------------------------------------------------------------------

    def get_enriched_context(self, query: str, max_chars: int = 2000) -> str:
        """Get enriched context string for use in LLM prompts."""
        result = self.retrieve(query, top_k=10)
        return result.to_context_string(max_chars=max_chars)

    def sync_with_persistent_memory(self):
        """Sync CA long-term memories with existing persistent memory entries.
        
        This reads the user's existing persistent memory and encodes them
        as long-term CA memories for associative retrieval.
        """
        # This would call the `memory` tool to read existing entries
        # For now, we note that this integration point exists
        logger.info("sync_with_persistent_memory: Call 'memory' tool to load existing persistent memory")
        logger.info("Then encode each entry as long_term CA memories for associative retrieval")

    def get_summary(self) -> str:
        """Get a human-readable summary of the current memory state."""
        stats = self.get_tier_stats()
        
        lines = [
            "=== Internal CA Memory State ===",
            f"CA Step: {self.ca_step}",
            "",
        ]
        
        for tier_name in ["short_term", "mid_term", "long_term"]:
            store = getattr(self, tier_name)
            count = len(store)
            avg_state = sum(t.state for t in store.values()) / max(1, count) if count else 0
            
            lines.append(f"{tier_name}: {count} memories (avg activation: {avg_state:.3f})")
            
            # Show top 3 strongest memories per tier
            if store:
                top_memories = sorted(store.items(), key=lambda x: x[1].state, reverse=True)[:3]
                for nid, trace in top_memories:
                    preview = trace.content[:80] + ("..." if len(trace.content) > 80 else "")
                    lines.append(f"  [{nid}] (state={trace.state:.3f}) {preview}")
        
        lines.append("")
        lines.append(f"Associative edges: {len(self.edges)}")
        lines.append(f"Total encoded: {self.metrics['total_memories_encoded']}")
        lines.append(f"Total retrievals: {self.metrics['total_retrievals']}")
        
        return "\n".join(lines)


# ============================================================================
# Module-level convenience functions
# ============================================================================

# Singleton instance for easy access across the agent
_instance: Optional[InternalCAMemory] = None

def get_ca_memory() -> InternalCAMemory:
    """Get or create the singleton CA memory instance."""
    global _instance
    if _instance is None:
        _instance = InternalCAMemory()
    return _instance


def reset_ca_memory():
    """Reset the singleton instance (for testing/reinitialization)."""
    global _instance
    _instance = None
