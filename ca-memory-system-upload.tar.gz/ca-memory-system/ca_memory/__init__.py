"""CA Memory Module - Persistent installation."""
__path__ = ["/home/adc/.hermes/custom_modules/ca_memory"]
